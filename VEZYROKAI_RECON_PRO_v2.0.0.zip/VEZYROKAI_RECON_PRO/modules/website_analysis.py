from urllib.parse import urlparse
from utils.net import fetch
from config import MAX_RESPONSE_BYTES

SECURITY_HEADERS = {
    "Strict-Transport-Security": "Helps enforce HTTPS",
    "Content-Security-Policy": "Can restrict content sources",
    "X-Content-Type-Options": "Helps prevent MIME sniffing",
    "X-Frame-Options": "Can reduce clickjacking risk",
    "Referrer-Policy": "Controls referrer information",
    "Permissions-Policy": "Controls selected browser features",
}

def run():
    url = input("Website URL: ").strip()
    if not urlparse(url).scheme:
        url = "https://" + url
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https") or not parsed.hostname or parsed.username or parsed.password:
        print("Enter a valid public HTTP/HTTPS URL (no embedded credentials).")
        return
    try:
        status, headers, body, final_url = fetch(url)
        print(f"\nFinal URL: {final_url}")
        print(f"HTTP status: {status}")
        print(f"Content type: {headers.get('Content-Type', 'Not disclosed')}")
        print(f"Server header: {headers.get('Server', 'Not disclosed')}")
        print(f"Received bytes: {len(body)} (response capped at {MAX_RESPONSE_BYTES})")
        print("\nSecurity header observations:")
        for name, explanation in SECURITY_HEADERS.items():
            present = bool(headers.get(name))
            print(f"  [{'+' if present else '-'}] {name}: {'present' if present else 'not observed'}")
            if present:
                print(f"      {explanation}")
        print("\nThese are basic observations, not a penetration test or security certification.")
    except Exception as exc:
        print(f"Website request failed: {exc}")
