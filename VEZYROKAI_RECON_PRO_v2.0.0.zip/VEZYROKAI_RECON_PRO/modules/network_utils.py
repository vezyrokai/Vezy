import socket
from urllib.parse import urlparse
from utils.net import fetch

def run():
    print("[1] Check HTTPS connectivity")
    print("[2] Resolve a hostname")
    choice = input("Choose: ").strip()
    if choice == "1":
        try:
            status, _, _, final_url = fetch("https://example.com")
            print(f"Connected. HTTP {status}; final URL: {final_url}")
        except Exception as exc:
            print(f"Connectivity check failed: {exc}")
    elif choice == "2":
        host = input("Hostname: ").strip()
        if "://" in host:
            host = urlparse(host).hostname or ""
        if not host or "/" in host or " " in host:
            print("Enter a hostname only.")
            return
        try:
            results = sorted({item[4][0] for item in socket.getaddrinfo(host, None)})
            print("\nResolved addresses:")
            for address in results:
                print("  " + address)
        except Exception as exc:
            print(f"DNS resolution failed: {exc}")
    else:
        print("Invalid option.")
