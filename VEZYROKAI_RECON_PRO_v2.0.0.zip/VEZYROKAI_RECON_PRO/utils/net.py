import json
import urllib.request
import urllib.error
from config import USER_AGENT, TIMEOUT, MAX_RESPONSE_BYTES

def fetch(url, method="GET", headers=None):
    merged = {"User-Agent": USER_AGENT}
    if headers:
        merged.update(headers)
    req = urllib.request.Request(url, headers=merged, method=method)
    with urllib.request.urlopen(req, timeout=TIMEOUT) as response:
        body = response.read(MAX_RESPONSE_BYTES + 1)
        if len(body) > MAX_RESPONSE_BYTES:
            raise ValueError("Response exceeded the 1 MB safety limit.")
        return response.status, response.headers, body, response.geturl()

def fetch_json(url):
    status, headers, body, final_url = fetch(url, headers={"Accept": "application/json"})
    return status, json.loads(body.decode("utf-8", errors="replace")), final_url
