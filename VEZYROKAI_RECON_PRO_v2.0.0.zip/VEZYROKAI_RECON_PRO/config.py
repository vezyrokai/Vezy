"""Central configuration for VEZYROKAI RECON PRO."""
APP_NAME = "VEZYROKAI RECON PRO"
VERSION = "2.0.0"
USER_AGENT = "VezyrokaiRecon/2.0 (educational passive lookup)"
TIMEOUT = 12
MAX_RESPONSE_BYTES = 1_000_000
