#!/usr/bin/env python3
"""VEZYROKAI RECON PRO - passive, permission-based reconnaissance."""
from modules import ip_info, domain_intel, dns_lookup, website_analysis, network_utils, username_osint
from utils.ui import banner, pause, section

MENU = {
    "1": ("IP information", ip_info.run),
    "2": ("Domain intelligence (RDAP)", domain_intel.run),
    "3": ("DNS record lookup", dns_lookup.run),
    "4": ("Website security overview", website_analysis.run),
    "5": ("Network utilities", network_utils.run),
    "6": ("Public username profile links", username_osint.run),
}

def main():
    while True:
        banner()
        for key, (label, _) in MENU.items():
            print(f"  [{key}] {label}")
        print("  [7] About / safety")
        print("  [8] Exit")
        choice = input("\n  vezy> ").strip()
        if choice in MENU:
            section(MENU[choice][0])
            try:
                MENU[choice][1]()
            except KeyboardInterrupt:
                print("\n[!] Cancelled.")
            except Exception as exc:
                print(f"\n[!] Unexpected error: {exc}")
            pause()
        elif choice == "7":
            section("ABOUT & SAFE USE")
            print("VEZYROKAI RECON PRO is an educational passive-recon toolkit.")
            print("Use it only on your own systems or where you have explicit permission.")
            print("It does not exploit systems, bypass logins, scan ports, or access private accounts.")
            print("IP geolocation is approximate and does not identify an exact person or home.")
            pause()
        elif choice == "8":
            print("\n  Vezyrokai out.\n")
            break
        else:
            print("\n[!] Choose a valid menu number.")

if __name__ == "__main__":
    main()
