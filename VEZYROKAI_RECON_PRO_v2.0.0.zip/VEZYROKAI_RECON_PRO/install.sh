#!/data/data/com.termux/files/usr/bin/bash
set -e
echo "Checking Python..."
if ! command -v python >/dev/null 2>&1; then
  pkg install python -y
fi
echo "No pip dependencies are required."
echo "Start with: python vezy.py"
