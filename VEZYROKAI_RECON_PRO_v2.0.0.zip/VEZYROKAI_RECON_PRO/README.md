# VEZYROKAI RECON PRO

**Version:** 2.0.0  
**Platform:** Python 3 / Termux / desktop  
**Type:** Passive, educational reconnaissance

A menu-driven toolkit for looking up public network and domain information. Built with Python's standard library; no pip installation is required.

## Features

| Module | What it does |
|---|---|
| IP information | Classifies an IP and optionally retrieves approximate public-IP network geolocation |
| Domain intelligence | Queries public RDAP registration data |
| DNS lookup | Queries A, AAAA, MX, NS, TXT, CNAME and SOA records |
| Website analysis | Reviews HTTP response details and selected security headers |
| Network utilities | Checks HTTPS connectivity and resolves hostnames |
| Username OSINT | Builds public profile URLs for manual review |

## Requirements

- Python 3.8+
- Internet connection for online lookups
- Termux users: install Python with `pkg install python`

## Run

```bash
python vezy.py
```

## Run tests

```bash
python -m unittest discover -s tests -v
```

## Safety and limitations

- Only use the tool on domains, websites, and systems you own or are explicitly authorized to assess.
- This is passive lookup only. It does not exploit vulnerabilities, brute-force logins, scan ports, bypass access controls, or access private accounts.
- IP geolocation is approximate and generally describes a network/provider region, not an individual's exact location.
- Public profile links are provided for manual review. The tool does not scrape profiles or establish that accounts belong to the same person.
- Missing security headers are observations, not proof that a website is vulnerable.

## Project structure

```text
VEZYROKAI_RECON_PRO/
├── vezy.py
├── config.py
├── install.sh
├── requirements.txt
├── README.md
├── LICENSE
├── .gitignore
├── modules/
│   ├── ip_info.py
│   ├── domain_intel.py
│   ├── dns_lookup.py
│   ├── website_analysis.py
│   ├── network_utils.py
│   └── username_osint.py
├── utils/
│   ├── net.py
│   └── validate.py
└── tests/
    └── test_validate.py
```

## License

MIT. See [LICENSE](LICENSE).
